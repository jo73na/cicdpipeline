const mongoose = require('mongoose')
const REPORTSSCHEMA = {
   
  lable:String,
  key:String,
  isFaviorute:{
    type:Boolean,default:false
  },
 

  
   
     
    

    
};

module.exports = REPORTSSCHEMA