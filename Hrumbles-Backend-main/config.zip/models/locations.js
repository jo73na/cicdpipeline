const mongoose = require('mongoose')
const LocationsSCHEMA = {
   name:String,
  status: { type:Boolean, default:true },
   
     
    

    
};

module.exports = LocationsSCHEMA