const mongoose = require('mongoose')
const skilsSCHEMA = {
   name:{type:String,required:true},
  status: { type:Boolean, default:true },
   
     
    

    
};

module.exports = skilsSCHEMA