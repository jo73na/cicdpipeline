
// export const BASE_URL = `https://apiv1.technoladders.com/api/v1`;
//   export const BASE = `https://apiv1.technoladders.com/`;
export const BASE = `http://localhost:8080/`
export const BASE_URL = `http://localhost:8080/api/v1`


    