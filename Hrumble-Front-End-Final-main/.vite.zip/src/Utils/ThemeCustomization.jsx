

  export const themefuction =(colorprimary)=>{
  const Custom = {
    colorPrimary:"#88a67e",
    colorSecondary:"#88a67e1a",
   
   // colorPrimary:"green",
   colorError: "#dc3545",
   colorSuccess: "#28a745",
   borderRadius: 0,
   // borderColor: "#f0f0f0",
   fontFamily: "",
   colorBgContainer: "#fff",
   colorBg: "#f5f5f5",
   colorBgLayout: "#fff",
 
     Button: {
       
       algorithm: true, // Enable algorithm
     },
   
   
   Input: {
     controlHeight: 39,
     borderRadius:0,
 
     algorithm: true, 
    
   },
   Select: {
     borderRadius:0,
 
 },
   Textarea: {
     borderRadius: 10,
   },
   Checkbox: {
   
     borderRadius: 10,
   },
   CheckboxGroup: {
     borderRadius: 10,
   },
   InputNumber: {
     borderRadius: 10,
   },
   Layout: {
     Header: {},
     Menu: {},
   },
 };
    return Custom
}
  


export const Styles = {
  colorPrimary: "Red",
  colorError: "#dc3545",
  theme_bg: "#f5f5f5",
  borderColor: "#f0f0f0",
  gray: "#858a99",
  fontFamily: "sans-serif",
};