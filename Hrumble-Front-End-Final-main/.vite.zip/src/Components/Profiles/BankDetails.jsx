import React from 'react'

const BankDetails = () => {
  return (
    <div>
      Bank Account Details
    </div>
  )
}

export default BankDetails
