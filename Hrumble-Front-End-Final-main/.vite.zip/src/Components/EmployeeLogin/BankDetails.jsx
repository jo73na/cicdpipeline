import React from 'react'

const BankDetails = () => {
  return (
    <div>
      Bank
    </div>
  )
}

export default BankDetails
