import { createContext } from 'react';

const ClientContext = createContext();

export default ClientContext;