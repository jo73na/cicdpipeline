import { createContext } from 'react';

const LeaveContext = createContext();

export default LeaveContext;