import { createContext } from 'react';

const ViewJobContext = createContext();

export default ViewJobContext;