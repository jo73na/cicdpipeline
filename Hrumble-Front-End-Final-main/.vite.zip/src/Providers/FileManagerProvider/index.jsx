import { createContext } from 'react';

const FileManagerContext = createContext();

export default FileManagerContext;