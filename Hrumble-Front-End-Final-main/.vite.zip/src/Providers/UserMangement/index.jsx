    import { createContext } from 'react';

    const UserManagementContext = createContext();

    export default UserManagementContext;