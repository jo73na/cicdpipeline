import { createContext } from 'react';

const InvoiceExpenceContext = createContext();

export default InvoiceExpenceContext;