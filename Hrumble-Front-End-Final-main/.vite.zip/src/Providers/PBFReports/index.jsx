import { createContext } from 'react';

const PBFContext = createContext();

export default PBFContext;