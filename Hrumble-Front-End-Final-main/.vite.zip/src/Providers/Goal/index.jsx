import { createContext } from 'react';

const GoalContext = createContext();

export default GoalContext;