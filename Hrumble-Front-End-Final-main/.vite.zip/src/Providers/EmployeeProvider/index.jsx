import { createContext } from 'react';

const EmployeeContext = createContext();

export default EmployeeContext;