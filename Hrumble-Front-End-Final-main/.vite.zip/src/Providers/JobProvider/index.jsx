import { createContext } from 'react';

const JobContext = createContext();

export default JobContext;