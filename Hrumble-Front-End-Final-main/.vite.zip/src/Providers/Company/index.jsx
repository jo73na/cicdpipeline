import { createContext } from 'react';

const CompanyContext = createContext();

export default CompanyContext;