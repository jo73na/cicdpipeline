import { createContext } from 'react';

const CandidateContext = createContext();

export default CandidateContext;