import { createContext } from 'react';

const SalesandMargettingContext = createContext();

export default SalesandMargettingContext;