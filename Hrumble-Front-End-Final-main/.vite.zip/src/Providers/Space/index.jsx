import { createContext } from 'react';

const SpaceContext = createContext();

export default SpaceContext;